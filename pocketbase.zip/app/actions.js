"use server"

export default OAuth2